import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:sriwaap/admin/admin_provider.dart';
import 'package:sriwaap/app_theme.dart';
import 'package:sriwaap/user_model.dart';

class TeacherListScreen extends ConsumerWidget {
  const TeacherListScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final teachers = ref.watch(filteredTeachersProvider);
    final search = ref.watch(teacherSearchProvider);

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          _TeacherHeader(
            searchValue: search,
            onSearch: (v) => ref.read(teacherSearchProvider.notifier).state = v,
            onAdd: () => showDialog(
              context: context,
              builder: (_) => _TeacherDialog(ref: ref),
            ),
          ),
          Expanded(
            child: teachers.when(
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (e, _) => Center(child: Text('Error: $e')),
              data: (list) => list.isEmpty
                  ? const Center(child: Text('No teachers found.'))
                  : ListView.separated(
                      padding: const EdgeInsets.all(16),
                      itemCount: list.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (context, i) =>
                          _TeacherTile(teacher: list[i], ref: ref),
                    ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TeacherHeader extends StatelessWidget {
  final String searchValue;
  final ValueChanged<String> onSearch;
  final VoidCallback onAdd;
  const _TeacherHeader({
    required this.searchValue,
    required this.onSearch,
    required this.onAdd,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: AppColors.divider)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text('Teachers', style: Theme.of(context).textTheme.titleLarge),
              const Spacer(),
              ElevatedButton.icon(
                onPressed: onAdd,
                icon: const Icon(Icons.add, size: 18),
                label: const Text('Add Teacher'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.teacherColor,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          TextField(
            onChanged: onSearch,
            decoration: const InputDecoration(
              hintText: 'Search by name, email or department...',
              prefixIcon: Icon(Icons.search, size: 20),
              isDense: true,
            ),
          ),
        ],
      ),
    );
  }
}

class _TeacherTile extends StatelessWidget {
  final Teacher teacher;
  final WidgetRef ref;
  const _TeacherTile({required this.teacher, required this.ref});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: CircleAvatar(
        backgroundColor: AppColors.teacherColor.withOpacity(0.1),
        child: Text(
          teacher.name.isNotEmpty ? teacher.name[0].toUpperCase() : '?',
          style: TextStyle(
            color: AppColors.teacherColor,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      title: Text(teacher.name, style: Theme.of(context).textTheme.bodyLarge),
      subtitle: Text(
        '${teacher.email} • ${teacher.department}',
        style: Theme.of(context).textTheme.bodyMedium,
      ),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          IconButton(
            icon: const Icon(Icons.edit_outlined, size: 18),
            onPressed: () => showDialog(
              context: context,
              builder: (_) => _TeacherDialog(existing: teacher, ref: ref),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline, size: 18, color: Colors.red),
            onPressed: () => showDialog(
              context: context,
              builder: (_) => AlertDialog(
                title: const Text('Remove Teacher'),
                content: Text(
                  'Delete ${teacher.name}? Their account will be deactivated.',
                ),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Cancel'),
                  ),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red,
                    ),
                    onPressed: () async {
                      await ref
                          .read(adminServiceProvider)
                          .deleteTeacher(teacher.id);
                      if (context.mounted) Navigator.pop(context);
                    },
                    child: const Text('Delete'),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TeacherDialog extends ConsumerStatefulWidget {
  final Teacher? existing;
  final WidgetRef ref;
  const _TeacherDialog({this.existing, required this.ref});

  @override
  ConsumerState<_TeacherDialog> createState() => _TeacherDialogState();
}

class _TeacherDialogState extends ConsumerState<_TeacherDialog> {
  late final TextEditingController _name;
  late final TextEditingController _email;
  late final TextEditingController _dept;
  bool _loading = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _name = TextEditingController(text: widget.existing?.name ?? '');
    _email = TextEditingController(text: widget.existing?.email ?? '');
    _dept = TextEditingController(text: widget.existing?.department ?? '');
  }

  @override
  void dispose() {
    _name.dispose();
    _email.dispose();
    _dept.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_name.text.isEmpty || _email.text.isEmpty) return;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final service = ref.read(adminServiceProvider);
      if (widget.existing != null) {
        await service.updateTeacher(
          widget.existing!.id,
          _name.text.trim(),
          _dept.text.trim(),
        );
      } else {
        await service.addTeacher(
          _name.text.trim(),
          _email.text.trim(),
          _dept.text.trim(),
        );
      }
      if (mounted) Navigator.pop(context);
    } catch (e) {
      setState(() {
        _loading = false;
        _error = e.toString();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.existing != null;
    return AlertDialog(
      title: Text(isEdit ? 'Edit Teacher' : 'New Teacher'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: _name,
            decoration: const InputDecoration(labelText: 'Full name'),
          ),
          const SizedBox(height: 12),
          if (!isEdit) ...[
            TextField(
              controller: _email,
              decoration: const InputDecoration(labelText: 'Email address'),
              keyboardType: TextInputType.emailAddress,
            ),
            const SizedBox(height: 4),
            Text(
              'Default password: Turquoise@2024',
              style: TextStyle(fontSize: 11, color: Colors.orange.shade700),
            ),
            const SizedBox(height: 12),
          ],
          TextField(
            controller: _dept,
            decoration: const InputDecoration(labelText: 'Department'),
          ),
          if (_error != null) ...[
            const SizedBox(height: 8),
            Text(
              _error!,
              style: const TextStyle(color: Colors.red, fontSize: 12),
            ),
          ],
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: _loading ? null : _save,
          child: _loading
              ? const SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: Colors.white,
                  ),
                )
              : Text(isEdit ? 'Save' : 'Add'),
        ),
      ],
    );
  }
}
