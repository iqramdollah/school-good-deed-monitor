import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:sriwaap/admin/admin_provider.dart';
import 'package:sriwaap/app_theme.dart';

class AnnualUpdateScreen extends ConsumerStatefulWidget {
  const AnnualUpdateScreen({super.key});

  @override
  ConsumerState<AnnualUpdateScreen> createState() => _AnnualUpdateScreenState();
}

class _AnnualUpdateScreenState extends ConsumerState<AnnualUpdateScreen> {
  // Default promotion map — admin can adjust
  final Map<String, String> _promotionMap = {
    'Year 1': 'Year 2',
    'Year 2': 'Year 3',
    'Year 3': 'Year 4',
    'Year 4': 'Year 5',
    'Year 5': 'Year 6',
  };

  bool _loading = false;
  String? _result;

  Future<void> _runUpdate() async {
    setState(() {
      _loading = true;
      _result = null;
    });
    final count = await ref
        .read(adminServiceProvider)
        .runAnnualUpdate(_promotionMap);
    setState(() {
      _loading = false;
      _result = '$count students promoted and points reset successfully.';
    });
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Annual Update',
            style: Theme.of(context).textTheme.displayMedium,
          ),
          const SizedBox(height: 4),
          Text(
            'Promote all students to the next class and reset good deed points.',
            style: Theme.of(context).textTheme.bodyMedium,
          ),
          const SizedBox(height: 24),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.orange.shade50,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.orange.shade200),
            ),
            child: Row(
              children: [
                Icon(
                  Icons.warning_amber_rounded,
                  color: Colors.orange.shade700,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'This action will update ALL students at once and cannot be undone. Run it once at the start of each new school year.',
                    style: TextStyle(
                      color: Colors.orange.shade800,
                      fontSize: 13,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          Text(
            'Class Promotion Map',
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const SizedBox(height: 12),
          ..._promotionMap.entries.map(
            (entry) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Row(
                children: [
                  Chip(
                    label: Text(entry.key),
                    backgroundColor: AppColors.studentColor.withOpacity(0.1),
                  ),
                  const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 12),
                    child: Icon(
                      Icons.arrow_forward,
                      size: 16,
                      color: AppColors.textSecondary,
                    ),
                  ),
                  Chip(
                    label: Text(entry.value),
                    backgroundColor: AppColors.primary.withOpacity(0.1),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),
          if (_result != null) ...[
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.green.shade50,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.green.shade200),
              ),
              child: Row(
                children: [
                  Icon(
                    Icons.check_circle_outline,
                    color: Colors.green.shade700,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    _result!,
                    style: TextStyle(color: Colors.green.shade700),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
          ],
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _loading
                  ? null
                  : () => showDialog(
                      context: context,
                      builder: (_) => AlertDialog(
                        title: const Text('Confirm Annual Update'),
                        content: const Text(
                          'This will promote all students and reset all points. Are you sure?',
                        ),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(context),
                            child: const Text('Cancel'),
                          ),
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.orange,
                            ),
                            onPressed: () {
                              Navigator.pop(context);
                              _runUpdate();
                            },
                            child: const Text('Run Update'),
                          ),
                        ],
                      ),
                    ),
              icon: _loading
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.white,
                      ),
                    )
                  : const Icon(Icons.update),
              label: const Text('Run Annual Update'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.orange,
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
