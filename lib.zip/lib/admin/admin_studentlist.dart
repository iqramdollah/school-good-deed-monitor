import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:sriwaap/admin/admin_provider.dart';
import 'package:sriwaap/app_theme.dart';
import 'package:sriwaap/user_model.dart';

class StudentListScreen extends ConsumerWidget {
  const StudentListScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final students = ref.watch(filteredStudentsProvider);
    final search = ref.watch(studentSearchProvider);

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          _Header(
            title: 'Students',
            searchValue: search,
            onSearch: (v) => ref.read(studentSearchProvider.notifier).state = v,
            onAdd: () => _showStudentDialog(context, ref),
          ),
          Expanded(
            child: students.when(
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (e, _) => Center(child: Text('Error: $e')),
              data: (list) => list.isEmpty
                  ? const Center(child: Text('No students found.'))
                  : ListView.separated(
                      padding: const EdgeInsets.all(16),
                      itemCount: list.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (context, i) =>
                          _StudentTile(student: list[i], ref: ref),
                    ),
            ),
          ),
        ],
      ),
    );
  }

  void _showStudentDialog(
    BuildContext context,
    WidgetRef ref, {
    Student? existing,
  }) {
    showDialog(
      context: context,
      builder: (_) => _StudentDialog(existing: existing, ref: ref),
    );
  }
}

class _Header extends StatelessWidget {
  final String title;
  final String searchValue;
  final ValueChanged<String> onSearch;
  final VoidCallback onAdd;

  const _Header({
    required this.title,
    required this.searchValue,
    required this.onSearch,
    required this.onAdd,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: AppColors.divider)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(title, style: Theme.of(context).textTheme.titleLarge),
              const Spacer(),
              ElevatedButton.icon(
                onPressed: onAdd,
                icon: const Icon(Icons.add, size: 18),
                label: Text('Add $title'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.studentColor,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          TextField(
            onChanged: onSearch,
            decoration: const InputDecoration(
              hintText: 'Search by name or class...',
              prefixIcon: Icon(Icons.search, size: 20),
              isDense: true,
            ),
          ),
        ],
      ),
    );
  }
}

class _StudentTile extends StatelessWidget {
  final Student student;
  final WidgetRef ref;
  const _StudentTile({required this.student, required this.ref});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      leading: CircleAvatar(
        backgroundColor: AppColors.studentColor.withOpacity(0.1),
        child: Text(
          student.name.isNotEmpty ? student.name[0].toUpperCase() : '?',
          style: TextStyle(
            color: AppColors.studentColor,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      title: Text(student.name, style: Theme.of(context).textTheme.bodyLarge),
      subtitle: Text(
        student.className,
        style: Theme.of(context).textTheme.bodyMedium,
      ),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            '${student.totalPoints} pts',
            style: TextStyle(
              color: AppColors.primary,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(width: 8),
          // Create account button
          IconButton(
            icon: const Icon(Icons.account_circle_outlined, size: 18),
            tooltip: 'Create student account',
            onPressed: () => _showCreateAccountDialog(context),
          ),
          IconButton(
            icon: const Icon(Icons.edit_outlined, size: 18),
            onPressed: () => showDialog(
              context: context,
              builder: (_) => _StudentDialog(existing: student, ref: ref),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline, size: 18, color: Colors.red),
            onPressed: () => _confirmDelete(context),
          ),
        ],
      ),
    );
  }

  void _showCreateAccountDialog(BuildContext context) {
    final emailController = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Create Account for ${student.name}'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'This will create a login account linked to this student. Default password: Turquoise@2024',
              style: TextStyle(fontSize: 12),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: emailController,
              decoration: const InputDecoration(
                labelText: 'Email address',
                prefixIcon: Icon(Icons.email_outlined),
              ),
              keyboardType: TextInputType.emailAddress,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              if (emailController.text.isEmpty) return;
              try {
                await ref.read(adminServiceProvider).addStudentAccount(
                  student.id,
                  emailController.text.trim(),
                );
                if (context.mounted) {
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Account created for ${student.name}'),
                      backgroundColor: Colors.green,
                    ),
                  );
                }
              } catch (e) {
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Error: $e'),
                      backgroundColor: Colors.red,
                    ),
                  );
                }
              }
            },
            child: const Text('Create'),
          ),
        ],
      ),
    );
  }

  void _confirmDelete(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Remove Student'),
        content: Text('Delete ${student.name}? This cannot be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () async {
              await ref.read(adminServiceProvider).deleteStudent(student.id);
              if (context.mounted) Navigator.pop(context);
            },
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }
}

class _StudentDialog extends ConsumerStatefulWidget {
  final Student? existing;
  final WidgetRef ref;
  const _StudentDialog({this.existing, required this.ref});

  @override
  ConsumerState<_StudentDialog> createState() => _StudentDialogState();
}

class _StudentDialogState extends ConsumerState<_StudentDialog> {
  late final TextEditingController _name;
  late final TextEditingController _class;
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _name = TextEditingController(text: widget.existing?.name ?? '');
    _class = TextEditingController(text: widget.existing?.className ?? '');
  }

  @override
  void dispose() {
    _name.dispose();
    _class.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_name.text.isEmpty || _class.text.isEmpty) return;
    setState(() => _loading = true);
    final service = ref.read(adminServiceProvider);
    if (widget.existing != null) {
      await service.updateStudent(
        widget.existing!.id,
        _name.text.trim(),
        _class.text.trim(),
      );
    } else {
      await service.addStudent(_name.text.trim(), _class.text.trim());
    }
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.existing != null;
    return AlertDialog(
      title: Text(isEdit ? 'Edit Student' : 'New Student'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: _name,
            decoration: const InputDecoration(labelText: 'Full name'),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _class,
            decoration: const InputDecoration(labelText: 'Class (e.g. Year 3)'),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: _loading ? null : _save,
          child: _loading
              ? const SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: Colors.white,
                  ),
                )
              : Text(isEdit ? 'Save' : 'Add'),
        ),
      ],
    );
  }
}
